package com.example.myapplication;

public class Student {

    String Id,Name,Phone,Email,Password;

    public Student(String id, String name, String phone, String email, String password) {
        Id = id;
        Name = name;
        Phone = phone;
        Email = email;
        Password = password;
    }
}
